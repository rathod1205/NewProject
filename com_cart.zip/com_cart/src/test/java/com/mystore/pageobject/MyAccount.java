package com.mystore.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MyAccount {
	WebDriver driver;
	
	public MyAccount (WebDriver driver)
	{
		 driver =driver;
		 PageFactory.initElements(driver,this);
	}
	@FindBy(id="email_create")
	WebElement emailInput;
	
	@FindBy(id = "SubmitCreate")
	WebElement SubmitBtn;
	
	public void EnterEmailAdd(String emailAdd)
	{
		emailInput.sendKeys(emailAdd);
	}
	public void ClickSubmitBtn()
	{
		SubmitBtn.click();
	}
	
	
}