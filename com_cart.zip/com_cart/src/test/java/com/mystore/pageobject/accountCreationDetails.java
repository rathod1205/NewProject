package com.mystore.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class accountCreationDetails {
	WebDriver driver;
	//Constructor
	public accountCreationDetails(WebDriver driver)
	{
		driver = driver;
		
		PageFactory.initElements(driver, this);
	}
	
		@FindBy(id="uniform-id_gender2")
		WebElement titleMrs;
		
		@FindBy(id= "customer_firstname")
		WebElement firstName;
		
		@FindBy(id= "customer_lastname")
		WebElement lastName;
		
		@FindBy(id="passwd")
		WebElement password;
		
		@FindBy(id= "days")
		WebElement birthDay;
		
		@FindBy(id="months")
		WebElement birthMonth;
		
		@FindBy(id="years")
		WebElement birthYear;
		
		@FindBy(id= "submitAccount")
		WebElement registerButton;
	
		//Idetnify the actions and perform the actions
		
		public void selectTitleMrs()
		{
			titleMrs.click();
		}
		public void enterFirstName(String fname)
		{
			firstName.sendKeys(fname);
		}
		public void enterLastName(String lname)
		{
			lastName.sendKeys(lname);
		}
		public void enterPass(String pwd)
		{
			password.sendKeys(pwd);
		}	
		
		public void enterBirthDay(String text)
		{
			Select sl = new Select(birthDay);
			sl.deselectByValue(text);
			
		}	
		public void enterBirthMonth(String text1)
		{
			Select sl = new Select(birthMonth);
			sl.deselectByValue(text1);
		}
		public void enterBirthYear(String text2)
		{
			Select sl = new Select(birthYear);
			sl.deselectByValue(text2);
		}
		public void clickRegisterbtn()
		{
			registerButton.click();
		
		}
}
