package com.mystore.testcases;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.apache.hc.core5.util.Timeout;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.* ;


import com.mystore.utilities.ReadConfig;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {
	ReadConfig readConfig = new ReadConfig();
	
	String url= readConfig.getBaseUrl();
	String browser = readConfig.getBrowser();
	
	public static WebDriver driver;
	public static Logger Logger;
	
	@BeforeClass
	public void setup()
	{
		switch (browser.toLowerCase()) 
		{
		
		case "chrome":
			WebDriverManager.chromedriver().setup();
			driver =new ChromeDriver();
			break;
			
		case "msedge":
			WebDriverManager.edgedriver().setup();
		driver =new EdgeDriver();
			break;
			
		case "firefox":
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			break;
		
		default:
			driver = null;
			break;
		
}
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		// for logging 
		Logger = LogManager.getLogger("MyStoreV1");
	
		}
	@AfterClass
	public void tearDown() {
	driver.close();
	driver.quit();
		
	}
}
