package com.mystore.testcases;

import org.testng.annotations.Test;

import com.mystore.pageobject.IndexPage;
import com.mystore.pageobject.MyAccount;
import com.mystore.pageobject.accountCreationDetails;

public class TC_MyAccountPageTest extends BaseClass {
	
	@Test
	public void verifyRegistrationAndLogin ()
	{
//Open URL
		driver.get(url);
		Logger.info("url Opened ");
		
		IndexPage  pg = new IndexPage(driver);
		pg.clickOnSignIn();
		
		Logger.info("Clicked on signin button");
		
		MyAccount pg1 = new MyAccount(driver);
		pg1.EnterEmailAdd("Krish12345@gmail.com");
		Logger.info("Entered email address in create account section");
		
		pg1.ClickSubmitBtn();
		Logger.info("clicked on sign in button");
		
		accountCreationDetails accCreationPg = new accountCreationDetails(driver);
		accCreationPg.selectTitleMrs();
		accCreationPg.enterFirstName("Krushna");
		accCreationPg.enterLastName("Rathod");
		accCreationPg.enterPass("Krish@1234");
		Logger.info("last name is entered ");
		
		accCreationPg.enterBirthDay("12");
		accCreationPg.enterBirthMonth("May");
		accCreationPg.enterBirthYear("1995");
		
		Logger.info(" personnal details has beed entered ");
		
	}
	

}
